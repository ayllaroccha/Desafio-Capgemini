function validarsenhaforca(){
  var senha = document.getElementById('senhaforca').value;
  var forca = 0;
  document.getElementById("impSenha").innerHTML= "";
  
  //código de requisitos minimos
  if((senha.length >=6)) {
    forca += 1;
  }if((senha.length >=6) && (senha.match(/[1-9]+/))){
    forca += 1;
  }
  if ((senha.length >=6) && (senha.match(/[a-z]+/))){
    forca += 1;
  }
  if ((senha.length >=6) && (senha.match(/[A-Z]+/))){
    forca += 1;
  }
  if ((senha.length >=6) && (senha.match(/[!@#$%^&*()-+]+/))){
    forca += 1;
  }
   mostrarforca(forca)
}
//função onde possibilita segurança da senha aparecer (fraca, média, boa, segura)
function mostrarforca(forca){
  document.getElementById("impforcasenh").innerHTML = "Força: " + forca;

 //configuração dos requisitos minimos   
  if(forca < 2){
      document.getElementById("imperrosenhaforca").innerHTML = "<span style='color: #ff0000'>Fraca</span";
  }else if ((forca >= 2 ) && (forca < 3)) {
    document.getElementById("imperrosenhaforca").innerHTML = "<span style='color: #ffD700'>Média</span";
  }else if ((forca >= 3 ) && (forca < 5)) {
    document.getElementById("imperrosenhaforca").innerHTML = "<span style='color: #7fff00'>Forte</span";
  }else if ((forca >= 5 ) && (forca < 6)) {
    document.getElementById("imperrosenhaforca").innerHTML = "<span style='color: #008000'>Segura</span";
  }
}
